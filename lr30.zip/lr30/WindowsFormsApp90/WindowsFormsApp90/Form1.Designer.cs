﻿
namespace WindowsFormsApp90
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbNewName = new System.Windows.Forms.TextBox();
            this.tbRemoveDir = new System.Windows.Forms.TextBox();
            this.stou = new System.Windows.Forms.Button();
            this.stor = new System.Windows.Forms.Button();
            this.rename = new System.Windows.Forms.Button();
            this.rmd = new System.Windows.Forms.Button();
            this.mkd = new System.Windows.Forms.Button();
            this.list = new System.Windows.Forms.Button();
            this.nlist = new System.Windows.Forms.Button();
            this.size = new System.Windows.Forms.Button();
            this.mdt = new System.Windows.Forms.Button();
            this.retr = new System.Windows.Forms.Button();
            this.dele = new System.Windows.Forms.Button();
            this.appe = new System.Windows.Forms.Button();
            this.tbHost = new System.Windows.Forms.TextBox();
            this.tbNewDir = new System.Windows.Forms.TextBox();
            this.tbPass = new System.Windows.Forms.TextBox();
            this.tbUpload = new System.Windows.Forms.TextBox();
            this.tbUser = new System.Windows.Forms.TextBox();
            this.FadList = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.create = new System.Windows.Forms.Button();
            this.upload = new System.Windows.Forms.Button();
            this.connect = new System.Windows.Forms.Button();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.label9 = new System.Windows.Forms.Label();
            this.settings = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.hostTextBox = new System.Windows.Forms.TextBox();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.usernameTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(469, 344);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 17);
            this.label8.TabIndex = 87;
            this.label8.Text = "tbRemoveDir";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(469, 286);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 17);
            this.label7.TabIndex = 86;
            this.label7.Text = "tbNewName";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(488, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 17);
            this.label6.TabIndex = 85;
            this.label6.Text = "tbNewDir";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(488, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 17);
            this.label5.TabIndex = 84;
            this.label5.Text = "tbHost";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(486, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 17);
            this.label4.TabIndex = 83;
            this.label4.Text = "tbPass";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(472, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.TabIndex = 82;
            this.label3.Text = "tbUpload";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(488, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 17);
            this.label2.TabIndex = 81;
            this.label2.Text = "tbUser";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(488, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 17);
            this.label1.TabIndex = 80;
            this.label1.Text = "textBox1";
            // 
            // tbNewName
            // 
            this.tbNewName.Location = new System.Drawing.Point(578, 283);
            this.tbNewName.Name = "tbNewName";
            this.tbNewName.Size = new System.Drawing.Size(225, 22);
            this.tbNewName.TabIndex = 79;
            // 
            // tbRemoveDir
            // 
            this.tbRemoveDir.Location = new System.Drawing.Point(578, 341);
            this.tbRemoveDir.Name = "tbRemoveDir";
            this.tbRemoveDir.Size = new System.Drawing.Size(225, 22);
            this.tbRemoveDir.TabIndex = 78;
            // 
            // stou
            // 
            this.stou.Location = new System.Drawing.Point(279, 337);
            this.stou.Name = "stou";
            this.stou.Size = new System.Drawing.Size(171, 30);
            this.stou.TabIndex = 77;
            this.stou.Text = "stou";
            this.stou.UseVisualStyleBackColor = true;
            this.stou.Click += new System.EventHandler(this.stou_Click);
            // 
            // stor
            // 
            this.stor.Location = new System.Drawing.Point(279, 286);
            this.stor.Name = "stor";
            this.stor.Size = new System.Drawing.Size(171, 30);
            this.stor.TabIndex = 76;
            this.stor.Text = "stor";
            this.stor.UseVisualStyleBackColor = true;
            this.stor.Click += new System.EventHandler(this.stor_Click);
            // 
            // rename
            // 
            this.rename.Location = new System.Drawing.Point(279, 231);
            this.rename.Name = "rename";
            this.rename.Size = new System.Drawing.Size(171, 30);
            this.rename.TabIndex = 75;
            this.rename.Text = "rename";
            this.rename.UseVisualStyleBackColor = true;
            this.rename.Click += new System.EventHandler(this.rename_Click);
            // 
            // rmd
            // 
            this.rmd.Location = new System.Drawing.Point(279, 180);
            this.rmd.Name = "rmd";
            this.rmd.Size = new System.Drawing.Size(171, 30);
            this.rmd.TabIndex = 74;
            this.rmd.Text = "rmd";
            this.rmd.UseVisualStyleBackColor = true;
            this.rmd.Click += new System.EventHandler(this.rmd_Click);
            // 
            // mkd
            // 
            this.mkd.Location = new System.Drawing.Point(279, 132);
            this.mkd.Name = "mkd";
            this.mkd.Size = new System.Drawing.Size(171, 30);
            this.mkd.TabIndex = 73;
            this.mkd.Text = "mkd";
            this.mkd.UseVisualStyleBackColor = true;
            this.mkd.Click += new System.EventHandler(this.mkd_Click);
            // 
            // list
            // 
            this.list.Location = new System.Drawing.Point(279, 81);
            this.list.Name = "list";
            this.list.Size = new System.Drawing.Size(171, 30);
            this.list.TabIndex = 72;
            this.list.Text = "list";
            this.list.UseVisualStyleBackColor = true;
            this.list.Click += new System.EventHandler(this.list_Click);
            // 
            // nlist
            // 
            this.nlist.Location = new System.Drawing.Point(279, 29);
            this.nlist.Name = "nlist";
            this.nlist.Size = new System.Drawing.Size(171, 30);
            this.nlist.TabIndex = 71;
            this.nlist.Text = "nlist";
            this.nlist.UseVisualStyleBackColor = true;
            this.nlist.Click += new System.EventHandler(this.nlist_Click);
            // 
            // size
            // 
            this.size.Location = new System.Drawing.Point(39, 397);
            this.size.Name = "size";
            this.size.Size = new System.Drawing.Size(171, 30);
            this.size.TabIndex = 70;
            this.size.Text = "size";
            this.size.UseVisualStyleBackColor = true;
            this.size.Click += new System.EventHandler(this.size_Click);
            // 
            // mdt
            // 
            this.mdt.Location = new System.Drawing.Point(39, 337);
            this.mdt.Name = "mdt";
            this.mdt.Size = new System.Drawing.Size(171, 30);
            this.mdt.TabIndex = 69;
            this.mdt.Text = "mdt";
            this.mdt.UseVisualStyleBackColor = true;
            this.mdt.Click += new System.EventHandler(this.mdt_Click);
            // 
            // retr
            // 
            this.retr.Location = new System.Drawing.Point(39, 286);
            this.retr.Name = "retr";
            this.retr.Size = new System.Drawing.Size(171, 30);
            this.retr.TabIndex = 68;
            this.retr.Text = "retr";
            this.retr.UseVisualStyleBackColor = true;
            this.retr.Click += new System.EventHandler(this.retr_Click);
            // 
            // dele
            // 
            this.dele.Location = new System.Drawing.Point(39, 231);
            this.dele.Name = "dele";
            this.dele.Size = new System.Drawing.Size(171, 28);
            this.dele.TabIndex = 67;
            this.dele.Text = "dele";
            this.dele.UseVisualStyleBackColor = true;
            this.dele.Click += new System.EventHandler(this.dele_Click);
            // 
            // appe
            // 
            this.appe.Location = new System.Drawing.Point(39, 177);
            this.appe.Name = "appe";
            this.appe.Size = new System.Drawing.Size(171, 33);
            this.appe.TabIndex = 66;
            this.appe.Text = "appe";
            this.appe.UseVisualStyleBackColor = true;
            this.appe.Click += new System.EventHandler(this.appe_Click);
            // 
            // tbHost
            // 
            this.tbHost.Location = new System.Drawing.Point(578, 190);
            this.tbHost.Name = "tbHost";
            this.tbHost.Size = new System.Drawing.Size(225, 22);
            this.tbHost.TabIndex = 65;
            // 
            // tbNewDir
            // 
            this.tbNewDir.Location = new System.Drawing.Point(578, 231);
            this.tbNewDir.Name = "tbNewDir";
            this.tbNewDir.Size = new System.Drawing.Size(225, 22);
            this.tbNewDir.TabIndex = 64;
            // 
            // tbPass
            // 
            this.tbPass.Location = new System.Drawing.Point(578, 143);
            this.tbPass.Name = "tbPass";
            this.tbPass.Size = new System.Drawing.Size(225, 22);
            this.tbPass.TabIndex = 63;
            // 
            // tbUpload
            // 
            this.tbUpload.Location = new System.Drawing.Point(578, 109);
            this.tbUpload.Name = "tbUpload";
            this.tbUpload.Size = new System.Drawing.Size(225, 22);
            this.tbUpload.TabIndex = 62;
            // 
            // tbUser
            // 
            this.tbUser.Location = new System.Drawing.Point(578, 68);
            this.tbUser.Name = "tbUser";
            this.tbUser.Size = new System.Drawing.Size(225, 22);
            this.tbUser.TabIndex = 61;
            // 
            // FadList
            // 
            this.FadList.FormattingEnabled = true;
            this.FadList.ItemHeight = 16;
            this.FadList.Location = new System.Drawing.Point(853, 71);
            this.FadList.Name = "FadList";
            this.FadList.Size = new System.Drawing.Size(229, 68);
            this.FadList.TabIndex = 60;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(578, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(225, 22);
            this.textBox1.TabIndex = 59;
            // 
            // create
            // 
            this.create.Location = new System.Drawing.Point(39, 129);
            this.create.Name = "create";
            this.create.Size = new System.Drawing.Size(171, 33);
            this.create.TabIndex = 58;
            this.create.Text = "create";
            this.create.UseVisualStyleBackColor = true;
            this.create.Click += new System.EventHandler(this.create_Click);
            // 
            // upload
            // 
            this.upload.Location = new System.Drawing.Point(39, 81);
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(171, 32);
            this.upload.TabIndex = 57;
            this.upload.Text = "upload";
            this.upload.UseVisualStyleBackColor = true;
            this.upload.Click += new System.EventHandler(this.upload_Click);
            // 
            // connect
            // 
            this.connect.Location = new System.Drawing.Point(39, 27);
            this.connect.Name = "connect";
            this.connect.Size = new System.Drawing.Size(171, 35);
            this.connect.TabIndex = 56;
            this.connect.Text = "connect";
            this.connect.UseVisualStyleBackColor = true;
            this.connect.Click += new System.EventHandler(this.connect_Click);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(948, 231);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(93, 130);
            this.treeView1.TabIndex = 88;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(831, 299);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 17);
            this.label9.TabIndex = 89;
            this.label9.Text = "TreeView";
            // 
            // settings
            // 
            this.settings.Location = new System.Drawing.Point(279, 397);
            this.settings.Name = "settings";
            this.settings.Size = new System.Drawing.Size(171, 30);
            this.settings.TabIndex = 90;
            this.settings.Text = "settings";
            this.settings.UseVisualStyleBackColor = true;
            this.settings.Click += new System.EventHandler(this.settings_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // hostTextBox
            // 
            this.hostTextBox.Location = new System.Drawing.Point(578, 489);
            this.hostTextBox.Name = "hostTextBox";
            this.hostTextBox.Size = new System.Drawing.Size(225, 22);
            this.hostTextBox.TabIndex = 93;
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Location = new System.Drawing.Point(578, 435);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(225, 22);
            this.passwordTextBox.TabIndex = 92;
            // 
            // usernameTextBox
            // 
            this.usernameTextBox.Location = new System.Drawing.Point(578, 383);
            this.usernameTextBox.Name = "usernameTextBox";
            this.usernameTextBox.Size = new System.Drawing.Size(225, 22);
            this.usernameTextBox.TabIndex = 91;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(451, 386);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 17);
            this.label10.TabIndex = 94;
            this.label10.Text = "usernameTextBox";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(451, 440);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(118, 17);
            this.label11.TabIndex = 95;
            this.label11.Text = "passwordTextBox";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(451, 492);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 17);
            this.label12.TabIndex = 96;
            this.label12.Text = "hostTextBox";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1117, 627);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.hostTextBox);
            this.Controls.Add(this.passwordTextBox);
            this.Controls.Add(this.usernameTextBox);
            this.Controls.Add(this.settings);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbNewName);
            this.Controls.Add(this.tbRemoveDir);
            this.Controls.Add(this.stou);
            this.Controls.Add(this.stor);
            this.Controls.Add(this.rename);
            this.Controls.Add(this.rmd);
            this.Controls.Add(this.mkd);
            this.Controls.Add(this.list);
            this.Controls.Add(this.nlist);
            this.Controls.Add(this.size);
            this.Controls.Add(this.mdt);
            this.Controls.Add(this.retr);
            this.Controls.Add(this.dele);
            this.Controls.Add(this.appe);
            this.Controls.Add(this.tbHost);
            this.Controls.Add(this.tbNewDir);
            this.Controls.Add(this.tbPass);
            this.Controls.Add(this.tbUpload);
            this.Controls.Add(this.tbUser);
            this.Controls.Add(this.FadList);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.create);
            this.Controls.Add(this.upload);
            this.Controls.Add(this.connect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNewName;
        private System.Windows.Forms.TextBox tbRemoveDir;
        private System.Windows.Forms.Button stou;
        private System.Windows.Forms.Button stor;
        private System.Windows.Forms.Button rename;
        private System.Windows.Forms.Button rmd;
        private System.Windows.Forms.Button mkd;
        private System.Windows.Forms.Button list;
        private System.Windows.Forms.Button nlist;
        private System.Windows.Forms.Button size;
        private System.Windows.Forms.Button mdt;
        private System.Windows.Forms.Button retr;
        private System.Windows.Forms.Button dele;
        private System.Windows.Forms.Button appe;
        private System.Windows.Forms.TextBox tbHost;
        private System.Windows.Forms.TextBox tbNewDir;
        private System.Windows.Forms.TextBox tbPass;
        private System.Windows.Forms.TextBox tbUpload;
        private System.Windows.Forms.TextBox tbUser;
        private System.Windows.Forms.ListBox FadList;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button create;
        private System.Windows.Forms.Button upload;
        private System.Windows.Forms.Button connect;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button settings;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TextBox hostTextBox;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.TextBox usernameTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}

